''' Create, save and run a new file (hello_world.py) and write a Python program
that outputs the message “Hello World!” using IDLE.'''

# add your code here