print('''public class Hello { \t
    public static void main(String[] args) {''')
print('''\t System.out.println("Привет, мир!"); \t
    }
}''')