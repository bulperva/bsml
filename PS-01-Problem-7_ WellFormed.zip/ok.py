x = 'A well-formed Java program has \n a main method with{ and }\n braces\n\n'

y = '''A System.out.println statement 
'has ( and ) and usually a 
String that starts and ends 
with a " character. \n
(But we type \" instead!)\n'''
print(x, y)